
// IdentifyPoemsDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "IdentifyPoems.h"
#include "IdentifyPoemsDlg.h"
#include "afxdialogex.h"

#include <iostream>
#include <fstream>
#include <time.h>
#include <stdlib.h>
#include <string>
using namespace std;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// ����Ӧ�ó��򡰹��ڡ��˵���� CAboutDlg �Ի���
class CAboutDlg : public CDialog{
public:
	CAboutDlg();

// �Ի�������
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

// ʵ��
protected:
	DECLARE_MESSAGE_MAP()
public:
//	afx_msg void OnTimer(UINT_PTR nIDEvent);
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD){
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX){
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
//	ON_WM_TIMER()
END_MESSAGE_MAP()


// CIdentifyPoemsDlg �Ի���
CIdentifyPoemsDlg::CIdentifyPoemsDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CIdentifyPoemsDlg::IDD, pParent){
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CIdentifyPoemsDlg::DoDataExchange(CDataExchange* pDX){
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CIdentifyPoemsDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_C1, &CIdentifyPoemsDlg::OnBnClickedC1)
	ON_BN_CLICKED(IDC_C2, &CIdentifyPoemsDlg::OnBnClickedC2)
	ON_BN_CLICKED(IDC_A1, &CIdentifyPoemsDlg::OnBnClickedA1)
	ON_BN_CLICKED(IDC_A2, &CIdentifyPoemsDlg::OnBnClickedA2)
	ON_BN_CLICKED(IDC_A3, &CIdentifyPoemsDlg::OnBnClickedA3)
	ON_BN_CLICKED(IDC_A4, &CIdentifyPoemsDlg::OnBnClickedA4)
	ON_BN_CLICKED(IDC_A5, &CIdentifyPoemsDlg::OnBnClickedA5)
	ON_BN_CLICKED(IDC_A6, &CIdentifyPoemsDlg::OnBnClickedA6)
	ON_BN_CLICKED(IDC_A7, &CIdentifyPoemsDlg::OnBnClickedA7)
	ON_BN_CLICKED(IDC_A8, &CIdentifyPoemsDlg::OnBnClickedA8)
	ON_BN_CLICKED(IDC_A9, &CIdentifyPoemsDlg::OnBnClickedA9)
	ON_BN_CLICKED(IDC_A10, &CIdentifyPoemsDlg::OnBnClickedA10)
	ON_BN_CLICKED(IDC_B1, &CIdentifyPoemsDlg::OnBnClickedB1)
	ON_BN_CLICKED(IDC_B2, &CIdentifyPoemsDlg::OnBnClickedB2)
	ON_BN_CLICKED(IDC_B3, &CIdentifyPoemsDlg::OnBnClickedB3)
	ON_BN_CLICKED(IDC_B4, &CIdentifyPoemsDlg::OnBnClickedB4)
	ON_BN_CLICKED(IDC_B5, &CIdentifyPoemsDlg::OnBnClickedB5)
	ON_BN_CLICKED(IDC_B6, &CIdentifyPoemsDlg::OnBnClickedB6)
	ON_BN_CLICKED(IDC_B7, &CIdentifyPoemsDlg::OnBnClickedB7)
	ON_BN_CLICKED(IDC_B8, &CIdentifyPoemsDlg::OnBnClickedB8)
	ON_BN_CLICKED(IDC_B9, &CIdentifyPoemsDlg::OnBnClickedB9)
	ON_BN_CLICKED(IDC_B10, &CIdentifyPoemsDlg::OnBnClickedB10)
	ON_BN_CLICKED(IDC_B11, &CIdentifyPoemsDlg::OnBnClickedB11)
	ON_BN_CLICKED(IDC_B12, &CIdentifyPoemsDlg::OnBnClickedB12)
	ON_BN_CLICKED(IDC_B13, &CIdentifyPoemsDlg::OnBnClickedB13)
	ON_BN_CLICKED(IDC_B14, &CIdentifyPoemsDlg::OnBnClickedB14)
	ON_BN_CLICKED(IDC_B15, &CIdentifyPoemsDlg::OnBnClickedB15)
	ON_BN_CLICKED(IDC_B16, &CIdentifyPoemsDlg::OnBnClickedB16)
END_MESSAGE_MAP()


// CIdentifyPoemsDlg ��Ϣ��������
BOOL CIdentifyPoemsDlg::OnInitDialog(){
	CDialog::OnInitDialog();

	// ��������...���˵������ӵ�ϵͳ�˵��С�

	// IDM_ABOUTBOX ������ϵͳ���Χ�ڡ�
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL){
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty()){
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// ���ô˶Ի����ͼ�ꡣ  ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�
	//  ִ�д˲���
	SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
	SetIcon(m_hIcon, FALSE);		// ����Сͼ��

	//��ʼ��
	Initialize();
	return TRUE;  // ���ǽ��������õ��ؼ������򷵻� TRUE
}

void CIdentifyPoemsDlg::OnSysCommand(UINT nID, LPARAM lParam){
	if ((nID & 0xFFF0) == IDM_ABOUTBOX){
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}else{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// �����Ի���������С����ť������Ҫ����Ĵ���
//  �����Ƹ�ͼ�ꡣ  ����ʹ���ĵ�/��ͼģ�͵� MFC Ӧ�ó���
//  �⽫�ɿ���Զ���ɡ�
void CIdentifyPoemsDlg::OnPaint(){
	if (IsIconic()){
		CPaintDC dc(this); // ���ڻ��Ƶ��豸������

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// ʹͼ���ڹ����������о���
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// ����ͼ��
		dc.DrawIcon(x, y, m_hIcon);
	}else{
		CDialog::OnPaint();
	}
}

//���û��϶���С������ʱϵͳ���ô˺���ȡ�ù��
//��ʾ��
HCURSOR CIdentifyPoemsDlg::OnQueryDragIcon(){
	return static_cast<HCURSOR>(m_hIcon);
}

//���ÿؼ�
void CIdentifyPoemsDlg::EnableControl(UINT uID, BOOL bEnable){
	GetDlgItem(uID)->EnableWindow(bEnable);
}
//���ÿؼ���
void CIdentifyPoemsDlg::SetControlText(UINT nID, LPCWSTR lpString){
	GetDlgItem(nID)->SetWindowText(lpString);
}
//��ȡ�ؼ���
CString CIdentifyPoemsDlg::GetControlText(UINT nID){
	CString cstring;
	GetDlgItem(nID)->GetWindowText(cstring);
	return cstring;
}
//��ȡ·��
void CIdentifyPoemsDlg::GetFilePath(){
	//��ʼ��FilePath����ȡ\\����
	TCHAR exePath[MAX_PATH];
	GetModuleFileName(NULL, exePath, MAX_PATH);
	int j = 0, k = 0;
	for (int i = 0; i < sizeof(exePath); i++)
	{
		FilePath[i] = '\0';
		if (exePath[i] == '\\')
		{
			j++;
		}
	}
	//FilePath��ֵ
	for (int i = 0; i < sizeof(exePath); i++)
	{
		FilePath[i] = exePath[i];
		if (exePath[i] == '\\')
		{
			k++;
			if (k == j)
			{
				//wsprintf(FilePath, _T("%s%s"), FilePath, _T("A.txt"));
				strcat(FilePath, "A.txt");
				break;
			}
		}
	}
}
//У���ļ�������
void CIdentifyPoemsDlg::VerifyFile(char* path){
	ifstream ifs(path);
	if (!ifs.is_open()){
		int backnum = MessageBox(_T("δ�ҵ����TwT"), _T("������˵�С����OwO"), MB_ICONEXCLAMATION | MB_ABORTRETRYIGNORE);
		if (backnum == IDABORT){
			exit(1);//��ֹ
		}
		else if (backnum == IDRETRY){
			VerifyFile(path);//����
		}
		else if (backnum == IDIGNORE){
			MessageBox(_T("�����ⲻ�����°�UwU		"), _T("��˵��û�ҵ����XwX"), MB_ICONEXCLAMATION | MB_OK);//����
		}
	}
}
//��ʼ��
void CIdentifyPoemsDlg::Initialize(){

	Buttonmode = 0;
	Scores = 0;
	srand(time(0));
	GetFilePath();//��ȡ·��
	VerifyFile(FilePath);
	for (int cleantext = 1000; cleantext <= 1029; cleantext++){
		SetControlText(cleantext, _T("\0"));
	}	SetControlText(IDC_C1, _T("��ʼ"));
	for (int enable = 1000; enable <= 1025; enable++){
		EnableControl(enable, FALSE);
	}	EnableControl(IDC_C2, FALSE);
	EnableControl(IDC_C1, TRUE);

	CFont * f;
	f = new CFont;
	f->CreateFont(50, // nHeight 
		23, // nWidth 
		0, // nEscapement 
		0, // nOrientation 
		FW_BLACK, // nWeight ��ϸ
		FALSE, // bItalic б��
		FALSE, // bUnderline �»���
		FALSE, // cStrikeOut ɾ����
		ANSI_CHARSET, // nCharSet �ַ���
		OUT_DEFAULT_PRECIS, // nOutPrecision ����
		CLIP_DEFAULT_PRECIS, // nClipPrecision ����
		DEFAULT_QUALITY, // nQuality �������
		DEFAULT_PITCH | FF_SWISS, // nPitchAndFamily 
		_T("����")); // lpszFac 
	for (int zt = 1000; zt <= 1029; zt++)GetDlgItem(zt)->SetFont(f);
}
//��ȡ����
int CIdentifyPoemsDlg::GetLine(char* path){
	char buffer[256];
	int LineNum = 0;
	ifstream ifs(path);
	if (!ifs.is_open()){
		exit(1);//��ֹ	
	}//�������
	while (true){//һֱѭ��
		if (ifs.eof()){
			break;
		}//�Ƿ�ĩβ
		ifs >> buffer;//��ֵ
		LineNum++;
	}//��ȡ����snum
	ifs.close();
	return LineNum;
}
//char*תtchar*
void CIdentifyPoemsDlg::CharToTchar(const char * _char, TCHAR * tchar)
{
	int iLength = MultiByteToWideChar(CP_ACP, 0, _char, -1, NULL, 0);
	MultiByteToWideChar(CP_ACP, 0, _char, -1, tchar, iLength);
}
//�����þ�
void CIdentifyPoemsDlg::RandomGetLine(char* path, int num){
	num = num * 2;
	ifstream  GSfs(path);
	if (!GSfs.is_open()){
		//cout << "δ�ҵ����" << endl;
		exit(1);
	}
	char sentence[256];//��
	int n, randnum = rand() % num;//�����

	//cout<<randnum/2;//��n��
	for (int j = 0; j <= randnum / 2; j++){

		GSfs >> sentence;
	}
	GSfs.close();//�ر��ļ�
	//cout<<sentence<<"     ";//��ȡ������

	if (randnum != 2){
		//cout<<randnum%2<<"    ";
		n = randnum % 2;
	}
	else{
		//cout<<0<<"    ";
		n = 0;
	}//��n��
	int g = 0;//ȷ���Ƿ�¼��
	if (n == 0){
		for (int k = 0; k<sizeof(sentence); k++){
			if (sentence[k] == ','){ g = 1; }
			if (g == 0){
				Sentences[k] = sentence[k];
			}
			else if (g == 1){
				Sentences[k] = '\0';
			}
		}
	}
	else if (n == 1){
		int f = 0;//�ڶ���¼��λ��
		for (int k = 0; k<sizeof(sentence); k++){
			if (sentence[k] == ','){
				g = 1;
				k++;//����","
			}
			if (g == 0){
				Sentences[f] = '\0';
			}
			else if (g == 1){
				if (sentence[k] == '.'){
					g = 0;
					continue;
				}
				Sentences[f] = sentence[k];
				f++;
			}
		}
	}
}
//ȥ����ͬ��
void CIdentifyPoemsDlg::RemoveSameWord(TCHAR* tchar1, TCHAR* tchar2){
	for (int i = 0; i < wcslen(tchar1); i++){
		for (int j = 0; j < wcslen(tchar2); j++){
			if (tchar1[i] == tchar2[j])tchar2[j] = _T('ث');
		}
	}
	TCHAR Tempchar[16] = { 0 };
	int g = 0;
	for (int k = 0; k < wcslen(tchar2); k++){
		if (tchar2[k] == _T('ث'))continue;
		Tempchar[g] = tchar2[k];
		g++;
	}
	for (int l = 0; l < wcslen(tchar2); l++){
		Temptchar[l] = Tempchar[l];
	}
}
//���������
void CIdentifyPoemsDlg::ConnectSentence(){
	RandomGetLine(FilePath, GetLine(FilePath));
	CharToTchar(Sentences, Temptchar);
	wcscpy(PutSentence, Temptchar);
	wcscpy(MainSentence, Temptchar);
	int c = wcslen(PutSentence);
	TCHAR samechar[10] = { 0 };
	int breakout = 0;
	int tc = 0, cr = 0;;//tc=Temptchar���ȣ�cr=���������һ����
	do{

		RandomGetLine(FilePath, GetLine(FilePath));
		CharToTchar(Sentences, Temptchar);
		RemoveSameWord(PutSentence, Temptchar);
		tc = wcslen(Temptchar);
		int j;
		int k = tc; k--;
		//wcscat(PutSentence, Temptchar);
		//Ӳ�ϲ�������Ӳ�ϲ�
		for (int i = 0; i <tc; i++){

			for (j = 0; j < 10; j++){
				if (Temptchar[i] == samechar[j]){
					breakout = 1;
					break;
				}
			}if (breakout == 1){ breakout = 0; continue; }//��ֹ���������ٴγ���

			if (i == k){
				samechar[cr] = Temptchar[i];
				break;
			}//����

			PutSentence[c] = Temptchar[i];
			c++;//����

			if (wcslen(PutSentence) == 16)break;
		}
		if (wcslen(PutSentence) == 16)break;
	} while (true);
}
//����
void CIdentifyPoemsDlg::PutON(UINT uID){
	CString Tempchar1 = GetControlText(uID), Nullchar = _T('\0');
	for (int i = 0; i < 10; i++){
		if (Tempchar1 == Nullchar)break;//��ǰ�ǿ�����
		if (i >= SentenceLength)continue;
		int j = i + 1000;
		CString Tempchar2 = GetControlText(j);
		if (Tempchar2 == Nullchar){

			From[i] = uID;
			SetControlText(j, Tempchar1);
			SetControlText(uID, Nullchar);
			EnableControl(j, TRUE);
			EnableControl(uID, FALSE);
			break;
		}
	}
	int test = SentenceLength;
	test--;
	if (From[test] != 0)EnableControl(IDC_C1, TRUE);
	SetControlText(IDC_S2, _T(""));
}
//�Ż�
void CIdentifyPoemsDlg::PutBack(UINT uID){
	CString Tempchar = GetControlText(uID), Nullchar = _T('\0');
	if (Tempchar != Nullchar){//��ǰ�ǿ�����
		int Tempnum = uID;
		Tempnum -= 1000;
		int Putbacknum = From[Tempnum];
		From[Tempnum] = 0;
		SetControlText(uID, Nullchar);
		SetControlText(Putbacknum, Tempchar);
		EnableControl(uID, FALSE);
		EnableControl(Putbacknum, TRUE);
	}
	int test = SentenceLength;
	test--;
	if (From[test] == 0)EnableControl(IDC_C1, FALSE);
	SetControlText(IDC_S2, _T(""));
}
//���ҷ���16����
void CIdentifyPoemsDlg::PutInto16(TCHAR* tchar){
	int SetWord[16];
	int randnum = 0;
	for (int i = 0; i < 16; i++){

		do{
			randnum = rand() % 16;
			if (SetWord[randnum] != randnum){
				SetWord[randnum] = randnum;
				break;
			}
		} while (true);
		int o = i + 1010;
		TCHAR into[2] = { 0 };
		into[0] = tchar[randnum];
		SetControlText(o, into);
	}
}
//У��
int CIdentifyPoemsDlg::CheckSentence(){
	int len = SentenceLength;
	len += 1000;
	CString temp;
	for (int i = 1000; i < len; i++){
		temp += GetControlText(i);
	}
	CString Main;
	Main.Format(L"%s", MainSentence);
	if (Main == temp)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}
//��һ��
void CIdentifyPoemsDlg::NextSentence(){
	ConnectSentence();
	SentenceLength = wcslen(MainSentence);
	PutInto16(PutSentence);
	EnableControl(IDC_C1, FALSE);
	SetControlText(IDC_C1, _T("��֤"));

	for (int i = 1000; i <= 1025; i++){
		if (i < 1010){
			EnableControl(i, FALSE);
			SetControlText(i, _T('\0'));
		}
		else{
			EnableControl(i, TRUE);
		}

	}//����&���ÿؼ�

	for (int k = 0; k < 10; k++){
		if (k < SentenceLength){
			CWnd *pwnd;
			pwnd = GetDlgItem(k + 1000);
			pwnd->ShowWindow(SW_SHOW);
		}
		else{
			CWnd *pwnd;
			pwnd = GetDlgItem(k + 1000);
			pwnd->ShowWindow(SW_HIDE);
		}
	}//������֤������
	//SetControlText(IDC_S2, MainSentence);//Mainsentence&PutSentence===========================================����
	SetControlText(IDC_S2, _T(""));
}
//IDC_C1
void CIdentifyPoemsDlg::OnBnClickedC1(){
	CString s;
	if (Buttonmode == 0)
	{
		Buttonmode++;
		EnableControl(IDC_C2, TRUE);
		NextSentence();
		s.Format(L"%s%d", _T("��ǰ�÷֣�"), Scores);
		SetControlText(IDC_S1, s);
		SetControlText(IDC_C2, _T("��һ��"));	
	}
	else
	{
		int tm = CheckSentence();
		if (tm == 1){
			Scores++;
			s.Format(L"%s%d", _T("��ǰ�÷֣�"), Scores);
			SetControlText(IDC_S1, s);
			NextSentence();
			SetControlText(IDC_S2, _T("��ȷ"));
		}
		else
		{
			SetControlText(IDC_S2, _T("����"));
		}
	}
}
//IDC_C2
void CIdentifyPoemsDlg::OnBnClickedC2(){
	NextSentence();
}

//10����֤��
void CIdentifyPoemsDlg::OnBnClickedA1(){
	PutBack(IDC_A1);
}
void CIdentifyPoemsDlg::OnBnClickedA2(){
	PutBack(IDC_A2);
}
void CIdentifyPoemsDlg::OnBnClickedA3(){
	PutBack(IDC_A3);
}
void CIdentifyPoemsDlg::OnBnClickedA4(){
	PutBack(IDC_A4);
}
void CIdentifyPoemsDlg::OnBnClickedA5(){
	PutBack(IDC_A5);
}
void CIdentifyPoemsDlg::OnBnClickedA6(){
	PutBack(IDC_A6); 
}
void CIdentifyPoemsDlg::OnBnClickedA7(){
	PutBack(IDC_A7);
}
void CIdentifyPoemsDlg::OnBnClickedA8(){
	PutBack(IDC_A8);
}
void CIdentifyPoemsDlg::OnBnClickedA9(){
	PutBack(IDC_A9);
}
void CIdentifyPoemsDlg::OnBnClickedA10(){
	PutBack(IDC_A10);
}

//16����ѡ��
void CIdentifyPoemsDlg::OnBnClickedB1(){
	PutON(IDC_B1);
}
void CIdentifyPoemsDlg::OnBnClickedB2(){
	PutON(IDC_B2);
}
void CIdentifyPoemsDlg::OnBnClickedB3(){
	PutON(IDC_B3);
}
void CIdentifyPoemsDlg::OnBnClickedB4(){
	PutON(IDC_B4);
}
void CIdentifyPoemsDlg::OnBnClickedB5(){
	PutON(IDC_B5);
}
void CIdentifyPoemsDlg::OnBnClickedB6(){
	PutON(IDC_B6);
}
void CIdentifyPoemsDlg::OnBnClickedB7(){
	PutON(IDC_B7);
}
void CIdentifyPoemsDlg::OnBnClickedB8(){
	PutON(IDC_B8);
}
void CIdentifyPoemsDlg::OnBnClickedB9(){
	PutON(IDC_B9);
}
void CIdentifyPoemsDlg::OnBnClickedB10(){
	PutON(IDC_B10);
}
void CIdentifyPoemsDlg::OnBnClickedB11(){
	PutON(IDC_B11);
}
void CIdentifyPoemsDlg::OnBnClickedB12(){
	PutON(IDC_B12);
}
void CIdentifyPoemsDlg::OnBnClickedB13(){
	PutON(IDC_B13); 
}
void CIdentifyPoemsDlg::OnBnClickedB14(){
	PutON(IDC_B14);
}
void CIdentifyPoemsDlg::OnBnClickedB15(){
	PutON(IDC_B15);
}
void CIdentifyPoemsDlg::OnBnClickedB16(){
	PutON(IDC_B16);
}